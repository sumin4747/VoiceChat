ALTER TABLE personas
    ADD COLUMN birth_date LocalDATE NULL;