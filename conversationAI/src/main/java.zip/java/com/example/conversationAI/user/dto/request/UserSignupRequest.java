package com.example.conversationAI.user.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record UserSignupRequest(
        @NotBlank(message = "email은 필수입니다.")
        @Email(message = "email 형식이 올바르지 않습니다.")
        String email,

        @NotBlank(message = "password는 필수입니다.")
        @Size(min = 8, max = 72, message = "password는 8~72자여야 합니다.")
        String password,

        @NotBlank(message = "nickname은 필수입니다.")
        @Size(max = 50, message = "nickname은 50자 이하여야 합니다.")
        String nickname
) {
    public UserSignupRequest {
        email = normalizeEmail(email);
        password = trimToNull(password);
        nickname = trimToNull(nickname);
    }

    private static String normalizeEmail(String v) {
        if (v == null) return null;
        String t = v.trim();
        return t.isEmpty() ? null : t.toLowerCase();
    }

    private static String trimToNull(String v) {
        if (v == null) return null;
        String t = v.trim();
        return t.isEmpty() ? null : t;
    }
}
