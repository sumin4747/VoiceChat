package com.example.conversationAI.message.dto.request;

import com.example.conversationAI.message.domain.MessageSender;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record CreateMessageRequest(

        @NotBlank(message = "content는 필수입니다.")
        String content
) {
    public CreateMessageRequest {
        content = trimToNull(content);
    }

    private static String trimToNull(String v) {
        if (v == null) return null;
        String t = v.trim();
        return t.isEmpty() ? null : t;
    }
}
