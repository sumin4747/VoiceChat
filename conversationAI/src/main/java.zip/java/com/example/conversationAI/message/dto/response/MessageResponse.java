package com.example.conversationAI.message.dto.response;

import com.example.conversationAI.message.domain.Message;
import com.example.conversationAI.message.domain.MessageSender;

import java.time.LocalDateTime;

public record MessageResponse(
        Long id,
        Long conversationId,
        MessageSender sender,
        String content,
        LocalDateTime createdAt
) {
    public static MessageResponse from(Message m) {
        return new MessageResponse(
                m.getId(),
                m.getConversationId(),
                m.getSender(),
                m.getContent(),
                m.getCreatedAt()
        );
    }
}
