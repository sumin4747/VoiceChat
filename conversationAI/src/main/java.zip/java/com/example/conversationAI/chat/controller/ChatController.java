package com.example.conversationAI.chat.controller;

import com.example.conversationAI.chat.service.ChatService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/voices/{voiceId}/chat")
@RequiredArgsConstructor
public class ChatController {

    private final ChatService chatService;

    @PostMapping
    public Map<String, String> chat(
            @PathVariable Long voiceId,
            @RequestBody Map<String, String> request
    ) {

        String message = request.get("message");

        if (message == null || message.isBlank()) {
            throw new IllegalArgumentException("message is required");
        }

        String reply = chatService.chat(voiceId, message);

        return Map.of(
                "replyText", reply
        );
    }

    @GetMapping("/messages")
    public Object history(@PathVariable Long voiceId) {
        return chatService.history(voiceId);
    }
}