package com.example.conversationAI.message.repository;

import com.example.conversationAI.message.domain.Message;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface MessageRepository extends JpaRepository<Message, Long> {

    List<Message> findAllByConversationIdAndDeletedAtIsNullOrderByCreatedAtAsc(Long conversationId);

    Optional<Message> findByIdAndConversationIdAndDeletedAtIsNull(Long id, Long conversationId);
}
