package com.example.conversationAI.user.service;

import com.example.conversationAI.user.domain.User;
import com.example.conversationAI.user.dto.request.UserPasswordChangeRequest;
import com.example.conversationAI.user.dto.request.UserSignupRequest;
import com.example.conversationAI.user.dto.response.UserResponse;
import com.example.conversationAI.user.repository.UserRepository;
import com.example.conversationAI.security.jwt.JwtProvider;
import com.example.conversationAI.user.dto.request.UserLoginRequest;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    private final JwtProvider jwtProvider;

    @PersistenceContext
    private EntityManager entityManager;

    public UserService(UserRepository userRepository, JwtProvider jwtProvider) {
        this.userRepository = userRepository;
        this.jwtProvider = jwtProvider;
    }
    public UserResponse signup(UserSignupRequest request) {

        String email = request.email();

        if (userRepository.existsByEmailAndDeletedAtIsNull(email)) {
            throw new DuplicateEmailException(email);
        }

        String hashed = passwordEncoder.encode(request.password());

        String nickname = request.nickname();

        User user = User.create(email, hashed, nickname);

        User saved = userRepository.save(user);

        return UserResponse.from(saved);
    }

    @Transactional(readOnly = true)
    public String login(UserLoginRequest request) {

        User user = userRepository.findByEmailAndDeletedAtIsNull(request.email())
                .orElseThrow(() -> new IllegalArgumentException("이메일 또는 비밀번호가 올바르지 않습니다."));

        if (!passwordEncoder.matches(request.password(), user.getPasswordHash())) {
            throw new IllegalArgumentException("이메일 또는 비밀번호가 올바르지 않습니다.");
        }

        return jwtProvider.generateToken(user.getId());
    }

    @Transactional(readOnly = true)
    public UserResponse getById(Long userId) {
        User user = userRepository.findByIdAndDeletedAtIsNull(userId)
                .orElseThrow(() -> new UserNotFoundException(userId));
        return UserResponse.from(user);
    }

    @Transactional
    public OtpLoginResult findOrCreateOtpUser(String email) {

        return userRepository.findByEmailAndDeletedAtIsNull(email)
                .map(user -> new OtpLoginResult(user, false))
                .orElseGet(() -> {
                    User newUser = User.createOtpUser(email);
                    userRepository.save(newUser);
                    return new OtpLoginResult(newUser, true);
                });
    }

    public UserResponse changePassword(Long userId, UserPasswordChangeRequest request) {

        User user = userRepository.findByIdAndDeletedAtIsNull(userId)
                .orElseThrow(() -> new UserNotFoundException(userId));

        String hashed = passwordEncoder.encode(request.newPassword());
        user.changePasswordHash(hashed);

        return UserResponse.from(user);
    }

    public void delete(Long userId) {
        User user = userRepository.findByIdAndDeletedAtIsNull(userId)
                .orElseThrow(() -> new UserNotFoundException(userId));

        user.delete();
    }

    public void block(Long userId) {
        User user = userRepository.findByIdAndDeletedAtIsNull(userId)
                .orElseThrow(() -> new UserNotFoundException(userId));
        user.block();
    }

    public static class DuplicateEmailException extends RuntimeException {
        public DuplicateEmailException(String email) {
            super("이미 사용 중인 이메일입니다: " + email);
        }
    }

    public static class UserNotFoundException extends RuntimeException {
        public UserNotFoundException(Long id) {
            super("사용자를 찾을 수 없습니다. id=" + id);
        }
    }

    public record OtpLoginResult(User user, boolean isNewUser) {}
}
