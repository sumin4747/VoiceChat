package com.example.conversationAI.conversation.dto.request;

import java.time.LocalDate;

public record CreateConversationRequest(
        LocalDate conversationDate
) {
}
