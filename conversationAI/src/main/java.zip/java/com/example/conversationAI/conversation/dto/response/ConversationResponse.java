package com.example.conversationAI.conversation.dto.response;

import com.example.conversationAI.conversation.domain.Conversation;

import java.time.LocalDate;
import java.time.LocalDateTime;

public record ConversationResponse(
        Long id,
        Long userId,
        Long personaId,
        LocalDate conversationDate,
        LocalDateTime createdAt
) {
    public static ConversationResponse from(Conversation c) {
        return new ConversationResponse(
                c.getId(),
                c.getUserId(),
                c.getPersonaId(),
                c.getConversationDate(),
                c.getCreatedAt()
        );
    }
}
