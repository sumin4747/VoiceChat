package com.example.conversationAI.voice.controller;

import com.example.conversationAI.voice.domain.VoiceModel;
import com.example.conversationAI.voice.service.VoiceModelService;
import com.example.conversationAI.voice.service.VoiceTrainingService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/personas/{personaId}/voice-models")
public class VoiceModelController {

    private final VoiceModelService voiceModelService;

    private final VoiceTrainingService trainingService;

    public VoiceModelController(VoiceModelService voiceModelService,
                                VoiceTrainingService trainingService) {
        this.voiceModelService = voiceModelService;
        this.trainingService = trainingService;
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> create(
            @PathVariable Long personaId,
            @RequestBody Map<String, String> request
    ) {
        VoiceModel model =
                voiceModelService.create(personaId, request.get("provider"));

        return ResponseEntity.ok(
                Map.of(
                        "voiceModelId", model.getId(),
                        "status", model.getStatus()
                )
        );
    }

    @GetMapping("/{modelId}")
    public ResponseEntity<Map<String, Object>> status(
            @PathVariable Long personaId,
            @PathVariable Long modelId
    ) {
        VoiceModel model =
                voiceModelService.get(personaId, modelId);

        return ResponseEntity.ok(
                Map.of(
                        "status", model.getStatus(),
                        "progressPercent", model.getProgressPercent()
                )
        );
    }

    @GetMapping
    public ResponseEntity<List<VoiceModel>> list(
            @PathVariable Long personaId
    ) {
        return ResponseEntity.ok(
                voiceModelService.list(personaId)
        );
    }

    @PostMapping("/{modelId}/upload")
    public ResponseEntity<?> upload(
            @PathVariable Long personaId,
            @PathVariable Long modelId,
            @RequestParam("file") MultipartFile file
    ) {

        VoiceModel model = voiceModelService.get(personaId, modelId);

        if (model.getStatus() != VoiceModel.Status.TRAINING) {
            throw new IllegalStateException("INVALID_STATE");
        }

        trainingService.simulateTraining(model.getId());

        return ResponseEntity.ok(
                Map.of("voiceModelId", model.getId())
        );
    }
}