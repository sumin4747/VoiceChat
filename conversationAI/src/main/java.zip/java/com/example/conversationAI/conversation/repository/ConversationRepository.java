package com.example.conversationAI.conversation.repository;

import com.example.conversationAI.conversation.domain.Conversation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface ConversationRepository extends JpaRepository<Conversation, Long> {

    List<Conversation> findAllByUserIdAndPersonaIdAndDeletedAtIsNullOrderByConversationDateDesc(Long userId, Long personaId);

    Optional<Conversation> findByIdAndUserIdAndPersonaIdAndDeletedAtIsNull(Long id, Long userId, Long personaId);

    Optional<Conversation> findByUserIdAndPersonaIdAndConversationDateAndDeletedAtIsNull(
            Long userId,
            Long personaId,
            LocalDate conversationDate
    );
}
