package com.example.conversationAI.conversation.service;

import com.example.conversationAI.conversation.domain.Conversation;
import com.example.conversationAI.conversation.dto.request.CreateConversationRequest;
import com.example.conversationAI.conversation.dto.response.ConversationResponse;
import com.example.conversationAI.conversation.repository.ConversationRepository;
import com.example.conversationAI.persona.repository.PersonaRepository;
import com.example.conversationAI.user.repository.UserRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class ConversationService {

    private final ConversationRepository conversationRepository;
    private final UserRepository userRepository;
    private final PersonaRepository personaRepository;

    public ConversationService(ConversationRepository conversationRepository,
                               UserRepository userRepository,
                               PersonaRepository personaRepository) {
        this.conversationRepository = conversationRepository;
        this.userRepository = userRepository;
        this.personaRepository = personaRepository;
    }

    public ConversationResponse create(Long userId, Long personaId, CreateConversationRequest request) {

        ensureUserExists(userId);
        ensurePersonaBelongsToUser(userId, personaId);

        LocalDate date = (request != null && request.conversationDate() != null)
                ? request.conversationDate()
                : LocalDate.now();

        Conversation existing =
                conversationRepository
                        .findByUserIdAndPersonaIdAndConversationDateAndDeletedAtIsNull(userId, personaId, date)
                        .orElse(null);

        if (existing != null) {
            return ConversationResponse.from(existing);
        }

        try {
            Conversation c = Conversation.create(userId, personaId, date);
            Conversation saved = conversationRepository.save(c);
            return ConversationResponse.from(saved);

        } catch (DataIntegrityViolationException e) {

            Conversation retry =
                    conversationRepository
                            .findByUserIdAndPersonaIdAndConversationDateAndDeletedAtIsNull(userId, personaId, date)
                            .orElseThrow(() -> e);

            return ConversationResponse.from(retry);
        }
    }

    @Transactional(readOnly = true)
    public List<ConversationResponse> list(Long userId, Long personaId) {
        ensureUserExists(userId);
        ensurePersonaBelongsToUser(userId, personaId);

        return conversationRepository
                .findAllByUserIdAndPersonaIdAndDeletedAtIsNullOrderByConversationDateDesc(userId, personaId)
                .stream()
                .map(ConversationResponse::from)
                .toList();
    }

    @Transactional(readOnly = true)
    public ConversationResponse get(Long userId, Long personaId, Long conversationId) {
        ensureUserExists(userId);
        ensurePersonaBelongsToUser(userId, personaId);

        Conversation c = conversationRepository
                .findByIdAndUserIdAndPersonaIdAndDeletedAtIsNull(conversationId, userId, personaId)
                .orElseThrow(() -> new ConversationNotFoundException(conversationId));

        return ConversationResponse.from(c);
    }

    public void delete(Long userId, Long personaId, Long conversationId) {
        ensureUserExists(userId);
        ensurePersonaBelongsToUser(userId, personaId);

        Conversation c = conversationRepository
                .findByIdAndUserIdAndPersonaIdAndDeletedAtIsNull(conversationId, userId, personaId)
                .orElseThrow(() -> new ConversationNotFoundException(conversationId));

        c.softDelete(LocalDateTime.now());
    }

    private void ensureUserExists(Long userId) {
        userRepository.findByIdAndDeletedAtIsNull(userId)
                .orElseThrow(() -> new UserNotFoundException(userId));
    }

    private void ensurePersonaBelongsToUser(Long userId, Long personaId) {
        personaRepository.findByIdAndUserId(personaId, userId)
                .orElseThrow(() -> new PersonaNotFoundException(personaId));
    }

    public static class UserNotFoundException extends RuntimeException {
        public UserNotFoundException(Long userId) {
            super("사용자를 찾을 수 없습니다. id=" + userId);
        }
    }

    public static class PersonaNotFoundException extends RuntimeException {
        public PersonaNotFoundException(Long personaId) {
            super("페르소나를 찾을 수 없습니다. id=" + personaId);
        }
    }

    public static class ConversationNotFoundException extends RuntimeException {
        public ConversationNotFoundException(Long conversationId) {
            super("대화를 찾을 수 없습니다. id=" + conversationId);
        }
    }
}
