package com.example.conversationAI.auth.controller;

import com.example.conversationAI.auth.dto.request.SendOtpRequest;
import com.example.conversationAI.auth.dto.request.VerifyOtpRequest;
import com.example.conversationAI.auth.dto.response.VerifyOtpResponse;
import com.example.conversationAI.auth.service.OtpCodeService;
import com.example.conversationAI.security.jwt.JwtProvider;
import com.example.conversationAI.user.domain.User;
import com.example.conversationAI.user.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/users/auth/otp")
public class OtpCodeController {

    private final OtpCodeService otpService;
    private final UserService userService;
    private final JwtProvider jwtProvider;

    public OtpCodeController(OtpCodeService otpService,
                         UserService userService,
                         JwtProvider jwtProvider) {
        this.otpService = otpService;
        this.userService = userService;
        this.jwtProvider = jwtProvider;
    }

    @PostMapping("/send")
    public ResponseEntity<Map<String, Object>> send(@RequestBody SendOtpRequest request) {

        int expires = otpService.sendOtp(request.email());

        return ResponseEntity.ok(
                Map.of(
                        "ok", true,
                        "expiresInSec", expires
                )
        );
    }

    @PostMapping("/verify")
    public ResponseEntity<VerifyOtpResponse> verify(@RequestBody VerifyOtpRequest request) {

        otpService.verify(request.email(), request.code());

        UserService.OtpLoginResult result =
                userService.findOrCreateOtpUser(request.email());

        String token = jwtProvider.generateToken(result.user().getId());

        VerifyOtpResponse response = new VerifyOtpResponse(
                token,
                result.isNewUser(),
                new VerifyOtpResponse.UserInfo(
                        result.user().getId(),
                        result.user().getNickname()
                )
        );

        return ResponseEntity.ok(response);
    }
}