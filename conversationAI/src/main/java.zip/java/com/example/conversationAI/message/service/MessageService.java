package com.example.conversationAI.message.service;

import com.example.conversationAI.conversation.domain.Conversation;
import com.example.conversationAI.conversation.repository.ConversationRepository;
import com.example.conversationAI.message.domain.Message;
import com.example.conversationAI.message.domain.MessageSender;
import com.example.conversationAI.message.dto.request.CreateMessageRequest;
import com.example.conversationAI.message.dto.response.MessageResponse;
import com.example.conversationAI.message.repository.MessageRepository;
import com.example.conversationAI.persona.repository.PersonaRepository;
import com.example.conversationAI.user.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class MessageService {

    private final MessageRepository messageRepository;
    private final ConversationRepository conversationRepository;
    private final UserRepository userRepository;
    private final PersonaRepository personaRepository;

    public MessageService(MessageRepository messageRepository,
                          ConversationRepository conversationRepository,
                          UserRepository userRepository,
                          PersonaRepository personaRepository) {
        this.messageRepository = messageRepository;
        this.conversationRepository = conversationRepository;
        this.userRepository = userRepository;
        this.personaRepository = personaRepository;
    }

    public MessageResponse create(Long userId, Long personaId, Long conversationId, CreateMessageRequest request) {
        ensureUserExists(userId);
        ensurePersonaBelongsToUser(userId, personaId);

        Conversation c = conversationRepository
                .findByIdAndUserIdAndPersonaIdAndDeletedAtIsNull(conversationId, userId, personaId)
                .orElseThrow(() -> new ConversationNotFoundException(conversationId));

        Message m = Message.create(c.getId(), MessageSender.user, request.content());
        Message saved = messageRepository.save(m);

        return MessageResponse.from(saved);
    }

    public MessageResponse createPersonaMessage(Long conversationId, String content) {

        Message m = Message.create(conversationId, MessageSender.persona, content);
        Message saved = messageRepository.save(m);

        return MessageResponse.from(saved);
    }

    public MessageResponse createSystemMessage(Long conversationId, String content) {

        Message m = Message.create(conversationId, MessageSender.system, content);
        Message saved = messageRepository.save(m);

        return MessageResponse.from(saved);
    }

    @Transactional(readOnly = true)
    public List<MessageResponse> list(Long userId, Long personaId, Long conversationId) {
        ensureUserExists(userId);
        ensurePersonaBelongsToUser(userId, personaId);

        Conversation c = conversationRepository
                .findByIdAndUserIdAndPersonaIdAndDeletedAtIsNull(conversationId, userId, personaId)
                .orElseThrow(() -> new ConversationNotFoundException(conversationId));

        return messageRepository.findAllByConversationIdAndDeletedAtIsNullOrderByCreatedAtAsc(c.getId()).stream()
                .map(MessageResponse::from)
                .toList();
    }

    @Transactional(readOnly = true)
    public MessageResponse get(Long userId, Long personaId, Long conversationId, Long messageId) {
        ensureUserExists(userId);
        ensurePersonaBelongsToUser(userId, personaId);

        Conversation c = conversationRepository
                .findByIdAndUserIdAndPersonaIdAndDeletedAtIsNull(conversationId, userId, personaId)
                .orElseThrow(() -> new ConversationNotFoundException(conversationId));

        Message m = messageRepository.findByIdAndConversationIdAndDeletedAtIsNull(messageId, c.getId())
                .orElseThrow(() -> new MessageNotFoundException(messageId));

        return MessageResponse.from(m);
    }

    public void delete(Long userId, Long personaId, Long conversationId, Long messageId) {
        ensureUserExists(userId);
        ensurePersonaBelongsToUser(userId, personaId);

        Conversation c = conversationRepository
                .findByIdAndUserIdAndPersonaIdAndDeletedAtIsNull(conversationId, userId, personaId)
                .orElseThrow(() -> new ConversationNotFoundException(conversationId));

        Message m = messageRepository.findByIdAndConversationIdAndDeletedAtIsNull(messageId, c.getId())
                .orElseThrow(() -> new MessageNotFoundException(messageId));

        m.softDelete(LocalDateTime.now());
    }

    private void ensureUserExists(Long userId) {
        userRepository.findByIdAndDeletedAtIsNull(userId)
                .orElseThrow(() -> new UserNotFoundException(userId));
    }

    private void ensurePersonaBelongsToUser(Long userId, Long personaId) {
        personaRepository.findByIdAndUserId(personaId, userId)
                .orElseThrow(() -> new PersonaNotFoundException(personaId));
    }

    public static class UserNotFoundException extends RuntimeException {
        public UserNotFoundException(Long userId) {
            super("사용자를 찾을 수 없습니다. id=" + userId);
        }
    }

    public static class PersonaNotFoundException extends RuntimeException {
        public PersonaNotFoundException(Long personaId) {
            super("페르소나를 찾을 수 없습니다. id=" + personaId);
        }
    }

    public static class ConversationNotFoundException extends RuntimeException {
        public ConversationNotFoundException(Long conversationId) {
            super("대화를 찾을 수 없습니다. id=" + conversationId);
        }
    }

    public static class MessageNotFoundException extends RuntimeException {
        public MessageNotFoundException(Long messageId) {
            super("메시지를 찾을 수 없습니다. id=" + messageId);
        }
    }
}
