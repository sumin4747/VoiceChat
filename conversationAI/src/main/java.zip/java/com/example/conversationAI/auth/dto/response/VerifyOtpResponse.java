package com.example.conversationAI.auth.dto.response;

public record VerifyOtpResponse(
        String token,
        boolean isNewUser,
        UserInfo user
) {
    public record UserInfo(Long userId, String nickname) {}
}
