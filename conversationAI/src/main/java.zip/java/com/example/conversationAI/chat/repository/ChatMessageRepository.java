package com.example.conversationAI.chat.repository;

import com.example.conversationAI.chat.domain.ChatMessage;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long> {

    List<ChatMessage> findByVoiceModelIdOrderByCreatedAtAsc(Long voiceModelId);
}