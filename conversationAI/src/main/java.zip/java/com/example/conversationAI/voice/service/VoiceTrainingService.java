package com.example.conversationAI.voice.service;

import com.example.conversationAI.voice.domain.VoiceModel;
import com.example.conversationAI.voice.repository.VoiceModelRepository;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class VoiceTrainingService {

    private final VoiceModelRepository repository;

    public VoiceTrainingService(VoiceModelRepository repository) {
        this.repository = repository;
    }

    @Async
    public void simulateTraining(Long voiceModelId) {

        try {
            for (int i = 1; i <= 10; i++) {
                Thread.sleep(1000);

                VoiceModel model = repository.findById(voiceModelId)
                        .orElseThrow();

                model.updateProgress(i * 10);
                repository.save(model);
            }

            VoiceModel model = repository.findById(voiceModelId)
                    .orElseThrow();

            model.markReady("external-model-" + voiceModelId);
            repository.save(model);

        } catch (InterruptedException e) {
            VoiceModel model = repository.findById(voiceModelId)
                    .orElseThrow();
            model.markFailed();
            repository.save(model);
        }
    }
}