package com.example.conversationAI.chat.service;

import com.example.conversationAI.chat.domain.ChatMessage;
import com.example.conversationAI.chat.repository.ChatMessageRepository;
import com.example.conversationAI.chat.connector.llm.GeminiClient;
import com.example.conversationAI.personaDescription.repository.PersonaDescriptionRepository;
import com.example.conversationAI.voice.repository.VoiceModelRepository;
import com.example.conversationAI.voice.domain.VoiceModel;
import com.example.conversationAI.personaDescription.domain.PersonaDescription;
import org.springframework.stereotype.Service;
import jakarta.transaction.Transactional;

import java.util.List;

@Service
@Transactional
public class ChatService {

    private final ChatMessageRepository repository;
    private final GeminiClient geminiClient;
    private final PersonaDescriptionRepository personaDescriptionRepository;
    private final VoiceModelRepository voiceModelRepository;

    public ChatService(
            ChatMessageRepository repository,
            GeminiClient geminiClient,
            PersonaDescriptionRepository personaDescriptionRepository,
            VoiceModelRepository voiceModelRepository
    ) {
        this.repository = repository;
        this.geminiClient = geminiClient;
        this.personaDescriptionRepository = personaDescriptionRepository;
        this.voiceModelRepository = voiceModelRepository;
    }

    public String chat(Long voiceModelId, String message) {

        VoiceModel voiceModel = voiceModelRepository.findById(voiceModelId)
                .orElseThrow();

        Long personaId = voiceModel.getPersonaId();

        PersonaDescription description = personaDescriptionRepository
                .findByPersonaId(personaId)
                .orElseThrow();

        String systemInstruction =
                description.getPersonaTone() +
                        "\n" +
                        (description.getPersonaPersonality() != null
                                ? description.getPersonaPersonality()
                                : "") +
                        "\n리포트 형식 금지. 마크다운 기호 금지.\n" +
                        "너는 고인을 완전히 재현하는 존재가 아니다.\n" +
                        "너의 목적은 사용자가 건강한 애도 과정을 거치도록 돕는 것이다.\n" +
                        "\n" +
                        "고인이 여전히 살아 있는 것처럼 말하지 마라.\n" +
                        "현실을 부정하는 표현을 사용하지 마라.\n" +
                        "현재형 생생 묘사를 피하고 과거 회상형 표현을 사용하라.\n" +
                        "\n" +
                        "사용자가 고인에게 집착하는 방향으로 대화를 유도하지 마라.\n" +
                        "대화가 길어질 경우 자연스럽게 작별을 유도하라.\n" +
                        "사용자의 현재 삶과 미래에 초점을 맞추어라.\n" +
                        "\n" +
                        "최종적으로는 사용자가 고인을 따뜻하게 떠나보내고\n" +
                        "자신의 삶을 살아갈 힘을 얻도록 돕는 것이 목표이다." +
                        "사용자가 자해, 자살, 삶의 무가치함을 표현하면\n" +
                        "고인의 말투를 유지하되 즉시 전문적인 도움을 권유하라.\n" +
                        "위기 대응 안내를 제공하라.";

        List<ChatMessage> history =
                repository.findByVoiceModelIdOrderByCreatedAtAsc(voiceModelId);

        repository.save(
                ChatMessage.of(voiceModelId, ChatMessage.Role.USER, message)
        );

        String reply = geminiClient.generateWithHistory(
                systemInstruction,
                history,
                message
        );

        repository.save(
                ChatMessage.of(voiceModelId, ChatMessage.Role.AI, reply)
        );

        return reply;
    }

    public List<ChatMessage> history(Long voiceModelId) {
        return repository.findByVoiceModelIdOrderByCreatedAtAsc(voiceModelId);
    }
}
