package com.example.conversationAI.auth.service;

import com.example.conversationAI.auth.domain.OtpCode;
import com.example.conversationAI.auth.repository.OtpCodeRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.concurrent.ThreadLocalRandom;

@Service
@Transactional
public class OtpCodeService {

    private final OtpCodeRepository otpRepository;

    public OtpCodeService(OtpCodeRepository otpRepository) {
        this.otpRepository = otpRepository;
    }

    public int sendOtp(String email) {
        String code = generateCode();
        OtpCode otp = OtpCode.create(email, code, 300);
        otpRepository.save(otp);
        System.out.println("DEV OTP CODE for " + email + " : " + code);
        return 300;
    }

    public void verify(String email, String code) {
        OtpCode otp = otpRepository
                .findTopByEmailAndCodeOrderByCreatedAtDesc(email, code)
                .orElseThrow(() -> new IllegalArgumentException("INVALID_OR_EXPIRED_CODE"));

        if (otp.isExpired() || otp.isVerified()) {
            throw new IllegalArgumentException("INVALID_OR_EXPIRED_CODE");
        }

        otp.markVerified();
    }

    private String generateCode() {
        int number = ThreadLocalRandom.current().nextInt(100000, 999999);
        return String.valueOf(number);
    }
}