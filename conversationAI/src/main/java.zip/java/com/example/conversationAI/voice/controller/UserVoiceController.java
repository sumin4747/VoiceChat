package com.example.conversationAI.voice.controller;

import com.example.conversationAI.chat.domain.ChatMessage;
import com.example.conversationAI.chat.service.ChatService;
import com.example.conversationAI.persona.domain.Persona;
import com.example.conversationAI.persona.service.PersonaService;
import com.example.conversationAI.voice.domain.VoiceModel;
import com.example.conversationAI.voice.service.VoiceModelService;
import com.example.conversationAI.voice.service.VoiceTrainingService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/users/voices")
public class UserVoiceController {

    private final PersonaService personaService;
    private final VoiceModelService voiceModelService;
    private final VoiceTrainingService trainingService;
    private final ChatService chatService;

    public UserVoiceController(
            PersonaService personaService,
            VoiceModelService voiceModelService,
            VoiceTrainingService trainingService,
            ChatService chatService
    ) {
        this.personaService = personaService;
        this.voiceModelService = voiceModelService;
        this.trainingService = trainingService;
        this.chatService = chatService;
    }

    @PostMapping
    public ResponseEntity<?> create(
            @AuthenticationPrincipal Long userId,
            @RequestBody Map<String, String> request
    ) {

        String personName = request.get("personName");
        String birthDate = request.get("birthDate");

        Persona persona = personaService.createRaw(userId, personName, birthDate);
        VoiceModel model = voiceModelService.create(persona.getId(), "local");

        return ResponseEntity.ok(
                Map.of(
                        "voiceId", model.getId(),
                        "status", "CREATED"
                )
        );
    }

    @PostMapping("/{voiceId}/upload")
    public ResponseEntity<?> upload(
            @PathVariable Long voiceId,
            @RequestParam("file") MultipartFile file
    ) {

        trainingService.simulateTraining(voiceId);

        return ResponseEntity.ok(
                Map.of("voiceId", voiceId)
        );
    }

    @GetMapping("/{voiceId}/status")
    public ResponseEntity<?> status(@PathVariable Long voiceId) {

        VoiceModel model = voiceModelService.getById(voiceId);

        return ResponseEntity.ok(
                Map.of(
                        "status", model.getStatus(),
                        "progressPercent", model.getProgressPercent()
                )
        );
    }

    @GetMapping
    public ResponseEntity<?> list(@AuthenticationPrincipal Long userId) {

        List<VoiceModel> models = voiceModelService.listByUser(userId);

        List<Map<String, Object>> response = models.stream()
                .map(model -> {
                    Map<String, Object> map = new HashMap<>();
                    map.put("voiceId", model.getId());
                    map.put("personName", model.getPersona().getPersonaName());
                    map.put("createdAt", model.getCreatedAt());
                    map.put("status", model.getStatus());
                    map.put("thumbnailUrl", null);
                    return map;
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(response);
    }

    @PostMapping("/{voiceId}/chat")
    public ResponseEntity<?> chat(
            @PathVariable Long voiceId,
            @RequestBody Map<String, String> request
    ) {

        String message = request.get("message");
        String reply = chatService.chat(voiceId, message);

        return ResponseEntity.ok(
                Map.of(
                        "replyText", reply,
                        "ttsAudioUrl", null
                )
        );
    }

    @GetMapping("/{voiceId}/messages")
    public ResponseEntity<?> history(@PathVariable Long voiceId) {

        List<ChatMessage> messages = chatService.history(voiceId);

        List<Map<String, Object>> response = messages.stream()
                .map(msg -> {
                    Map<String, Object> map = new HashMap<>();
                    map.put("role", msg.getRole().name());
                    map.put("content", msg.getContent());
                    map.put("createdAt", msg.getCreatedAt());
                    return map;
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(response);
    }
}