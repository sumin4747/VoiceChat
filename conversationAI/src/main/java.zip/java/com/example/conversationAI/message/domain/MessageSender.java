package com.example.conversationAI.message.domain;

public enum MessageSender {
    user, persona, system
}
