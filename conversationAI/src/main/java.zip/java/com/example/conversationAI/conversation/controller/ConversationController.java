package com.example.conversationAI.conversation.controller;

import com.example.conversationAI.conversation.dto.request.CreateConversationRequest;
import com.example.conversationAI.conversation.dto.response.ConversationResponse;
import com.example.conversationAI.conversation.service.ConversationService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/users/{userId}/personas/{personaId}/conversations")
public class ConversationController {

    private final ConversationService conversationService;

    public ConversationController(ConversationService conversationService) {
        this.conversationService = conversationService;
    }

    @PostMapping
    public ResponseEntity<ConversationResponse> create(@PathVariable Long userId,
                                                       @PathVariable Long personaId,
                                                       @RequestBody(required = false) @Valid CreateConversationRequest request) {

        ConversationResponse response = conversationService.create(userId, personaId, request);

        URI location = ServletUriComponentsBuilder
                .fromCurrentRequest()
                .path("/{conversationId}")
                .buildAndExpand(response.id())
                .toUri();

        return ResponseEntity.created(location).body(response);
    }

    @GetMapping
    public ResponseEntity<List<ConversationResponse>> list(@PathVariable Long userId,
                                                           @PathVariable Long personaId) {
        return ResponseEntity.ok(conversationService.list(userId, personaId));
    }

    @GetMapping("/{conversationId}")
    public ResponseEntity<ConversationResponse> get(@PathVariable Long userId,
                                                    @PathVariable Long personaId,
                                                    @PathVariable Long conversationId) {
        return ResponseEntity.ok(conversationService.get(userId, personaId, conversationId));
    }

    @DeleteMapping("/{conversationId}")
    public ResponseEntity<Void> delete(@PathVariable Long userId,
                                       @PathVariable Long personaId,
                                       @PathVariable Long conversationId) {
        conversationService.delete(userId, personaId, conversationId);
        return ResponseEntity.noContent().build();
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidation(MethodArgumentNotValidException e,
                                                          HttpServletRequest request) {
        List<ErrorResponse.FieldErrorItem> errors = e.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(fe -> new ErrorResponse.FieldErrorItem(
                        fe.getField(),
                        fe.getDefaultMessage() == null ? "invalid" : fe.getDefaultMessage()
                ))
                .toList();

        ErrorResponse body = ErrorResponse.of(
                HttpStatus.BAD_REQUEST.value(),
                "VALIDATION_ERROR",
                "요청 값이 올바르지 않습니다.",
                request.getRequestURI(),
                errors
        );

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
    }

    @ExceptionHandler(ConversationService.UserNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleUserNotFound(ConversationService.UserNotFoundException e,
                                                            HttpServletRequest request) {
        ErrorResponse body = ErrorResponse.of(
                HttpStatus.NOT_FOUND.value(),
                "USER_NOT_FOUND",
                e.getMessage(),
                request.getRequestURI()
        );
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
    }

    @ExceptionHandler(ConversationService.PersonaNotFoundException.class)
    public ResponseEntity<ErrorResponse> handlePersonaNotFound(ConversationService.PersonaNotFoundException e,
                                                               HttpServletRequest request) {
        ErrorResponse body = ErrorResponse.of(
                HttpStatus.NOT_FOUND.value(),
                "PERSONA_NOT_FOUND",
                e.getMessage(),
                request.getRequestURI()
        );
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
    }

    @ExceptionHandler(ConversationService.ConversationNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleConversationNotFound(ConversationService.ConversationNotFoundException e,
                                                                    HttpServletRequest request) {
        ErrorResponse body = ErrorResponse.of(
                HttpStatus.NOT_FOUND.value(),
                "CONVERSATION_NOT_FOUND",
                e.getMessage(),
                request.getRequestURI()
        );
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<ErrorResponse> handleDataIntegrity(DataIntegrityViolationException e,
                                                             HttpServletRequest request) {
        String detail = (e.getMostSpecificCause() != null && e.getMostSpecificCause().getMessage() != null)
                ? e.getMostSpecificCause().getMessage()
                : "constraint violation";

        ErrorResponse body = ErrorResponse.of(
                HttpStatus.CONFLICT.value(),
                "DATA_INTEGRITY_VIOLATION",
                detail,
                request.getRequestURI()
        );
        return ResponseEntity.status(HttpStatus.CONFLICT).body(body);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleException(Exception e,
                                                         HttpServletRequest request) {
        ErrorResponse body = ErrorResponse.of(
                HttpStatus.INTERNAL_SERVER_ERROR.value(),
                "INTERNAL_SERVER_ERROR",
                "서버 오류가 발생했습니다.",
                request.getRequestURI()
        );
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(body);
    }

    public record ErrorResponse(
            LocalDateTime timestamp,
            int status,
            String code,
            String message,
            String path,
            List<FieldErrorItem> errors
    ) {
        public static ErrorResponse of(int status, String code, String message, String path) {
            return new ErrorResponse(LocalDateTime.now(), status, code, message, path, List.of());
        }

        public static ErrorResponse of(int status, String code, String message, String path, List<FieldErrorItem> errors) {
            return new ErrorResponse(LocalDateTime.now(), status, code, message, path, errors);
        }

        public record FieldErrorItem(String field, String reason) {}
    }
}
